import express from "express";
import dotenv from "dotenv";
import archiver from "archiver";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

dotenv.config();
const app = express();
app.use(express.json({ limit: "1mb" }));

const PORT = Number(process.env.PORT || 3000);
const generatedDir = path.resolve("generated");
fs.mkdirSync(generatedDir, { recursive: true });

app.use("/downloads", express.static(generatedDir, {
  dotfiles: "deny",
  index: false,
  setHeaders(res) { res.setHeader("Content-Disposition", "attachment"); }
}));

app.use((req, res, next) => {
  const expected = process.env.APP_ACCESS_TOKEN || "";
  if (expected) {
    const supplied = req.header("X-App-Token") || "";
    if (supplied.length !== expected.length ||
        !crypto.timingSafeEqual(Buffer.from(supplied), Buffer.from(expected))) {
      return res.status(401).json({ error: "Unauthorized" });
    }
  }
  next();
});

app.get("/health", (_req, res) => res.json({ ok: true, service: "Virox AI" }));

function historyToMessages(history, message) {
  const clean = Array.isArray(history) ? history.slice(-12) : [];
  const messages = clean
    .filter(x => x && ["user", "assistant"].includes(x.role) && typeof x.content === "string")
    .map(x => ({ role: x.role, content: x.content.slice(0, 8000) }));
  messages.push({ role: "user", content: message.slice(0, 8000) });
  return messages;
}

async function callOpenAICompatible({ base, key, model, messages, referer }) {
  const r = await fetch(`${base}/chat/completions`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${key}`,
      "Content-Type": "application/json",
      ...(referer ? { "HTTP-Referer": referer, "X-Title": "Virox AI" } : {})
    },
    body: JSON.stringify({ model, messages, temperature: 0.7 })
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data?.error?.message || `Provider HTTP ${r.status}`);
  const answer = data?.choices?.[0]?.message?.content;
  if (!answer) throw new Error("Provider returned an empty answer");
  return answer;
}

async function callGemini(messages) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error("Gemini key not configured");
  const contents = messages.map(m => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }]
  }));
  const model = process.env.GEMINI_MODEL || "gemini-2.0-flash";
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`;
  const r = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents,
      generationConfig: { temperature: 0.7, maxOutputTokens: 4096 }
    })
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data?.error?.message || `Gemini HTTP ${r.status}`);
  const answer = data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("");
  if (!answer) throw new Error("Gemini returned an empty answer");
  return answer;
}

async function askProviders(messages) {
  const providers = [];
  if (process.env.GEMINI_API_KEY) providers.push(["Gemini", () => callGemini(messages)]);
  if (process.env.GROQ_API_KEY) providers.push(["Groq", () => callOpenAICompatible({
    base: "https://api.groq.com/openai/v1",
    key: process.env.GROQ_API_KEY,
    model: process.env.GROQ_MODEL || "llama-3.3-70b-versatile",
    messages
  })]);
  if (process.env.OPENROUTER_API_KEY) providers.push(["OpenRouter", () => callOpenAICompatible({
    base: "https://openrouter.ai/api/v1",
    key: process.env.OPENROUTER_API_KEY,
    model: process.env.OPENROUTER_MODEL || "liquid/lfm-3-1.7b:free",
    messages,
    referer: "https://virox-ai.local"
  })]);

  if (!providers.length) throw new Error("لم يتم إعداد أي مفتاح API على الخادم.");
  const errors = [];
  for (const [name, fn] of providers) {
    try { return { answer: await fn(), provider: name }; }
    catch (e) { errors.push(`${name}: ${e.message}`); }
  }
  throw new Error(errors.join(" | "));
}

app.post("/chat", async (req, res) => {
  try {
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "message is required" });
    if (message.length > 8000) return res.status(413).json({ error: "message too long" });
    const messages = historyToMessages(req.body.history, message);
    const result = await askProviders(messages);
    res.json(result);
  } catch (e) {
    res.status(502).json({ error: "تعذر الحصول على رد من مزودي الذكاء الاصطناعي.", details: e.message });
  }
});

function extractJson(text) {
  const cleaned = text.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("لم يرجع النموذج بنية ملفات صالحة.");
  return JSON.parse(cleaned.slice(start, end + 1));
}

app.post("/generate-project", async (req, res) => {
  const prompt = typeof req.body?.prompt === "string" ? req.body.prompt.trim() : "";
  if (!prompt) return res.status(400).json({ error: "prompt is required" });
  if (prompt.length > 3000) return res.status(413).json({ error: "prompt too long" });

  try {
    const instruction = [
      "You are a software project generator.",
      "Return ONLY valid JSON, no markdown, with this schema:",
      '{"projectName":"short-name","files":[{"path":"README.md","content":"file text"}]}',
      "Generate a useful starter project for this request:",
      prompt,
      "Rules: maximum 25 files; each path must be relative; no ../, no absolute paths; no secrets; include a README; provide complete file contents."
    ].join("\n");
    const result = await askProviders([{ role: "user", content: instruction }]);
    const project = extractJson(result.answer);
    if (!Array.isArray(project.files) || project.files.length < 1 || project.files.length > 25) {
      throw new Error("عدد الملفات غير صالح (1 إلى 25).");
    }

    const safeName = String(project.projectName || "ViroxProject")
      .replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 40) || "ViroxProject";
    const id = crypto.randomUUID();
    const zipName = `${safeName}_${id.slice(0, 8)}.zip`;
    const zipPath = path.join(generatedDir, zipName);
    const output = fs.createWriteStream(zipPath);
    const archive = archiver("zip", { zlib: { level: 6 } });

    const done = new Promise((resolve, reject) => {
      output.on("close", resolve);
      archive.on("error", reject);
    });
    archive.pipe(output);

    for (const file of project.files) {
      const rel = String(file.path || "").replace(/\\/g, "/");
      if (!rel || rel.startsWith("/") || rel.split("/").includes("..")) continue;
      const content = String(file.content || "").slice(0, 200000);
      archive.append(content, { name: rel });
    }
    archive.finalize();
    await done;

    // Temporary artifacts are cleaned by the host's scheduled cleanup; do not store private files here.
    const origin = `${req.protocol}://${req.get("host")}`;
    res.json({ fileName: zipName, downloadUrl: `${origin}/downloads/${encodeURIComponent(zipName)}`, provider: result.provider });
  } catch (e) {
    res.status(502).json({ error: "تعذر إنشاء المشروع.", details: e.message });
  }
});

app.listen(PORT, () => console.log(`Virox AI server listening on ${PORT}`));
